#include "GameManager.h"

int main()
{
	GameManager::StartGame();

	return 0;
}